<?php
/**
 * Plugin Name: Remove Avada Fusion Shortcodes
 * Description: Removes [fusion_*] shortcodes and replaces raw image URLs with <img> tags.
 * Version: 1.8
 * Author: J Media Group LLC
 */

if (!defined('ABSPATH')) exit;

add_action('admin_menu', 'fusion_shortcode_add_admin_menu');

function fusion_shortcode_add_admin_menu() {
    add_management_page(
        'Remove Fusion Shortcodes',
        'Remove Fusion Shortcodes',
        'manage_options',
        'remove-fusion-shortcodes',
        'render_fusion_shortcode_cleanup_page'
    );
}

function render_fusion_shortcode_cleanup_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized');
    }

    echo '<div class="wrap"><h1>Remove Avada Fusion Shortcodes</h1>';
    if (isset($_POST['run_cleanup']) && check_admin_referer('run_fusion_cleanup')) {
        $result = run_fusion_cleanup();
        echo '<div class="notice notice-success"><p>' . htmlspecialchars($result) . '</p></div>';
    }
    echo '<form method="post">';
    wp_nonce_field('run_fusion_cleanup');
    echo '<p><input type="submit" name="run_cleanup" class="button button-primary" value="Run Cleanup"></p>';
    echo '</form></div>';
}

function run_fusion_cleanup() {
    global $wpdb;
    $posts = $wpdb->get_results("SELECT ID, post_content FROM {$wpdb->posts} WHERE post_type = 'post' AND post_status = 'publish'");
    $count = 0;

    foreach ($posts as $post) {
        $cleaned = clean_fusion_shortcodes($post->post_content);
        $converted = convert_plain_image_urls_to_img_tags($cleaned);

        if ($converted !== $post->post_content) {
            wp_update_post(array(
                'ID' => $post->ID,
                'post_content' => $converted
            ));
            $count++;
        }
    }

    return "$count posts cleaned.";
}

function clean_fusion_shortcodes($content) {
    $content = preg_replace('/\[(fusion_[^\s\]]+)[^\]]*\]/i', '', $content);
    $content = preg_replace('/\[\/fusion_[^\]]*\]/i', '', $content);
    return $content;
}

function convert_plain_image_urls_to_img_tags($content) {
    $pattern = '/(https?:\/\/[^\s"'<>]+\.(jpg|jpeg|png|gif|webp))/i';
    return preg_replace_callback($pattern, 'wrap_image_url_with_img_tag', $content);
}

function wrap_image_url_with_img_tag($matches) {
    return '<img src="' . $matches[1] . '" alt="" />';
}
